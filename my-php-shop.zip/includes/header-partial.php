<!-- Header -->
<header id="partial-headerWrapper">
	<div id="partial-back-flower"></div>
	<div id="partial-logotext"></div>
	<div id="partial-fore-flower"></div>
</header>

<div class="container-fluid">
