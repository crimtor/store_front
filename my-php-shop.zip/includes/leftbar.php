		<!-- Left Sidebar -->

		<div class="col-md-2" id="left_sidebar">
			<?php include 'widgets/filters.php'; ?>
		</div>
