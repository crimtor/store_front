<!-- Right Sidebar -->
<div class="col-md-2" id="right_sidebar">
  <?php
    include 'widgets/cart.php';
    include 'widgets/recent.php';
    ?>
</div>
